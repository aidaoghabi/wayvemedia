"use client";

import React from "react";

export function Logo3() {
  return (
    <section className="overflow-hidden py-12 md:py-16 lg:py-20 scheme-1 alternate logo-alt">
      <div className="container mb-8 max-w-lg px-[5%] md:mb-10 lg:mb-12">
        <h1 className="text-center text-h6 font-bold">
          Trusted by startups and Fortune 500 brands
        </h1>
      </div>
      <div className="flex items-center pt-7 md:pt-0">
        <div className="flex shrink-0 animate-loop-horizontally items-center">
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 1"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 1"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 2"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 2"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 3"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 3"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 4"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 4"
          />
        </div>
        <div className="flex shrink-0 animate-loop-horizontally items-center">
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 5"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 5"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 6"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 6"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 7"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 7"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
            alt="Webflow logo 8"
          />
          <img
            className="mx-7 max-h-12 shrink-0 md:mx-10 md:max-h-14"
            src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
            alt="Relume logo 8"
          />
        </div>
      </div>
    </section>
  );
}
